import keyboard
import time
import pyperclip
import os

SEND_DELAY = 0.4
TEXT_COLOR = "\033[91m"
RESET_COLOR = "\033[0m"


def clear_screen():
    """Очищает экран консоли"""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_bloody(text):
    """Печатает текст кровавым цветом"""
    print(f"{TEXT_COLOR}{text}{RESET_COLOR}")


def get_text_files():
    """Получает список txt файлов в текущей папке"""
    files = []
    for file in os.listdir('.'):
        if file.endswith('.txt') and os.path.isfile(file):
            files.append(file)
    return sorted(files)


def show_menu():
    """Показывает кровавое меню выбора файла"""
    clear_screen()

    print_bloody("=" * 60)
    print_bloody("🩸 КРОВАВЫЙ ТЕЛЕГРАМ МАКРОС 🩸")
    print_bloody("=" * 60)
    print_bloody("Доступные файлы со словами:")
    print_bloody("=" * 60)

    files = get_text_files()

    if not files:
        print_bloody("Не найдено txt файлов в этой папке!")
        print_bloody("Создайте файл words.txt с вашими словами")
        return None

    for i, file in enumerate(files, 1):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                line_count = sum(1 for line in f if line.strip())
            print_bloody(f"{i}. {file} ({line_count} слов)")
        except:
            print_bloody(f"{i}. {file} (ошибка чтения)")

    print_bloody("=" * 60)
    print_bloody("Управление:")
    print_bloody("F3 - Запустить макрос с выбранным файлом")
    print_bloody("F4 - Выключить макрос")
    print_bloody("R - Обновить список файлов")
    print_bloody("ESC - Выход")
    print_bloody("=" * 60)

    return files


def load_words_from_file(filename):
    """Загружает слова из файла"""
    words = []
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                word = line.strip()
                if word:
                    words.append(word)

        print_bloody(f"Загружено {len(words)} слов из файла {filename}")
        return words

    except Exception as e:
        print_bloody(f"Ошибка при чтении файла {filename}: {e}")
        return []


def send_words(selected_file):
    """Функция для отправки слов в Telegram"""
    words = load_words_from_file(selected_file)

    if not words:
        print_bloody("Нет слов для отправки!")
        return

    print_bloody(f"🩸 НАЧИНАЮ КРОВАВЫЙ ВВОД 🩸")
    print_bloody(f"Файл: {selected_file}")
    print_bloody(f"Слов: {len(words)}")
    print_bloody(f"Скорость: {SEND_DELAY} сек/слово")
    print_bloody(f"Примерное время: {len(words) * SEND_DELAY:.1f} секунд")
    print_bloody("Переключитесь на Telegram в течение 3 секунд...")

    time.sleep(3)

    print_bloody("Ввод начался! F4 - остановить")

    for i, word in enumerate(words, 1):
        if keyboard.is_pressed('f4'):
            print_bloody("🩸 ВВОД ПРЕРВАН ПО F4 🩸")
            return

        pyperclip.copy(word)
        keyboard.press_and_release('ctrl+v')
        keyboard.press_and_release('enter')

        time.sleep(SEND_DELAY)

        if i % 5 == 0 or i == len(words):
            print_bloody(f"🩸 Введено {i}/{len(words)} слов 🩸")

    print_bloody("🩸 ВВОД ЗАВЕРШЕН 🩸")


def main():
    """Основная функция"""
    current_files = None
    selected_file = None

    while True:
        current_files = show_menu()

        if not current_files:
            print_bloody("Нажмите любую клавишу для продолжения...")
            keyboard.get_hotkey_name()
            time.sleep(1)
            continue

        print_bloody("Выберите файл (цифра) или управление:")

        event = keyboard.read_event(suppress=True)

        if event.event_type == keyboard.KEY_DOWN:
            if event.name == 'esc':
                print_bloody("🩸 ВЫХОД ИЗ КРОВАВОГО МАКРОСА 🩸")
                break

            elif event.name == 'r':
                continue

            elif event.name == 'f3':
                if selected_file:
                    print_bloody(f"Запускаю с файлом: {selected_file}")
                    time.sleep(1)
                    send_words(selected_file)
                    print_bloody("Нажмите любую клавишу для продолжения...")
                    keyboard.get_hotkey_name()
                else:
                    print_bloody("Сначала выберите файл цифрой!")
                    time.sleep(1)

            elif event.name == 'f4':
                print_bloody("🩸 МАКРОС ОСТАНОВЛЕН ПО F4 🩸")
                time.sleep(1)

            elif event.name.isdigit():
                file_index = int(event.name) - 1
                if 0 <= file_index < len(current_files):
                    selected_file = current_files[file_index]
                    print_bloody(f"Выбран файл: {selected_file}")
                    time.sleep(1)
                else:
                    print_bloody("Неверный номер файла!")
                    time.sleep(1)


if __name__ == "__main__":
    if not get_text_files():
        print_bloody("Создаю примерный файл words.txt...")
        with open("words.txt", "w", encoding="utf-8") as f:
            f.write("Кровавый\nМакрос\nТелеграм\nPython\nРаботает\nОтлично!\n")
        print_bloody("Создан файл words.txt с примерными словами")
        time.sleep(2)

    main()